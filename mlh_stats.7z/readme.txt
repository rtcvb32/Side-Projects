 These statistics are based on a few different sources, although they won't be present.

 Each of the output's only specify lenght/distance or raw. This means the remainders are all locked at 20 bits, since this is tested on a 1Meg sample that's just fine. This is intended to find the best general ratio without the other elements differing in some small ways, allowing 8000 tests rather than brute forcing some million number of tests.

 For simplicity I've sorted the output so the smallest numbers are on top, which are the best compression/options for those particular types. Quite curious to see how it varies based on little changes.

Dense data:
 This represents uncompressable data, namely an archive. A tiny amount of compression can be noted due to likely filenames that are similar.

Sources:
 Source code a good portion of it from random junk I had laying around, different languages.

Text:
 From stories and larger more natural language archives.

Repetative:
 A source file with several iterations where a good portion of the data is identical or can be
used.